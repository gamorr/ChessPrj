package chess;

public class Bishop extends ChessPiece {

    public Bishop(Player player) {
        super(player);
    }

    public String type() {
        return "Bishop";
    }

    public boolean isValidMove(Move move, IChessPiece[][] board) {


        //Top Right

        if (super.isValidMove(move, board)) {
            if (Math.abs(move.toColumn - move.fromCol) == Math.abs(move.toRow - move.fromRow)) {
                if ((move.toRow < move.fromRow) && (move.toColumn > move.fromCol)) {
                    for (int i = 1; i < (move.toColumn - move.fromCol); ++i) {
                        if (board[move.fromRow - i][move.fromCol + i] != null) {
                            return false;
                        }
                    }
                    return true;
                }

                //top left


                if ((move.toRow < move.fromRow) && (move.toColumn < move.fromCol)) {
                    for (int i = 1; i < (move.fromCol - move.toColumn); ++i) {
                        if (board[move.fromRow - i][move.fromCol - i] != null) {
                            return false;
                        }
                    }
                    return true;
                }


                //bottom right

                if ((move.toRow > move.fromRow) && (move.toColumn > move.fromCol)) {
                    for (int i = 1; i < (move.toRow - move.fromRow); ++i) {
                        if (board[move.fromRow + i][move.fromCol + i] != null) {
                            return false;
                        }
                    }
                    return true;
                }


                //bottom left


                if ((move.toRow > move.fromRow) && (move.toColumn < move.fromCol)) {
                    for (int i = 1; i < (move.toRow - move.fromRow); ++i) {
                        if (board[move.fromRow + i][move.fromCol - i] != null) {
                            return false;
                        }
                    }
                    return true;
                }
            }
        }
        return false;
    }

}